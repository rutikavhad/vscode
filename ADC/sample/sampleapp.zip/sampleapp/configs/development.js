'use strict';

let devConfig = {
    hostname: 'localhost',
    port: 3000,
    viewDir: './app/views'
};

module.exports = devConfig;
