'use strict';

let prodConfig = {
  hostname: 'reinsureservices.com',
  port: 8081,
  viewDir: './app/views'
};

module.exports = prodConfig;
