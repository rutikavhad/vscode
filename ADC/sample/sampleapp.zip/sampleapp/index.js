'use strict';
require('babel-polyfill');
const server = require('./server')();
const config=require('./configs');
const db=require('./configs/db');
const terminate = require('./utils/terminate');
try {
  server.create(config, db);
  server.start();

  const exitHandler = terminate(server, {
    coredump: false,
    timeout: 500
  })

  process.on('uncaughtException', exitHandler(1, 'Unexpected Error'))
  process.on('unhandledRejection', exitHandler(1, 'Unhandled Promise'))
  process.on('SIGTERM', exitHandler(1, 'SIGTERM'))
  process.on('SIGINT', exitHandler(1, 'SIGINT'))

} catch (error) {
  throw error;
}
