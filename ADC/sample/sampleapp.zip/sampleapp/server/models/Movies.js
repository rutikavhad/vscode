'use strict';

const mongoose = require('mongoose');

const MoviesSchema = new mongoose.Schema({
    id: { type: String, unique: true, required: true },
    name: { type: String, required: true },
    created_at: { type: Date },
    updated_at: { type: Date }
}, {
    timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' }
}, { strict: false });

MoviesSchema.pre('save', function(next) {
    return next();
});


MoviesSchema.index({
    'id': 'text',
    'name': 'text',
}, { name: "moviesIndex" });

const Movies = mongoose.model('Movies', MoviesSchema, 'movies');
module.exports = Movies;