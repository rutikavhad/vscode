const Movies=require('./Movies');
module.exports={
  Movies: Movies
};  